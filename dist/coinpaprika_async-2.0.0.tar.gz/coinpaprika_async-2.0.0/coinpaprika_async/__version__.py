__title__ = "coinpaprika_async"
__description__ = "An asynchronous client for the coinpaprika API."
__version__ = "2.0.0"
